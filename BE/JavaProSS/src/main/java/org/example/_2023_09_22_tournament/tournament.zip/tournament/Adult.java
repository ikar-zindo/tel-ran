package org.example._2023_09_22_tournament.tournament;

public class Adult extends Participant {

   public Adult(String name, int age) {
      super(name, age);
   }
}

class Student extends Participant {
   public Student(String name, int age) {
      super(name, age);
   }
}

class Pupil extends Participant {
   public Pupil(String name, int age) {
      super(name, age);
   }
}