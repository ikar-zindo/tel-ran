package org.example._2023_09_22_tournament.tournament;

public enum TypeParticipant {
   ADULT,
   STUDENT,
   PUPIL
}
